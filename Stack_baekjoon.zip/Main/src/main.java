import java.util.*;

public class main {

	public static void main(String[] args) {
		Stack<Integer> stack = new Stack<>(); //java.util.Stack���� �����޴� Stack ���̺귯��
		Scanner sc = new Scanner(System.in);
		
		int num = sc.nextInt();
		String order;
		int data = 0;
		int buffer;
		boolean buffer2;
		
		for(int i = 0; i < num; i++) {
			order = sc.next(); //�� �ܾ �޵��� ����!
			
			switch(order) {
			case "push":
				data = sc.nextInt();
				stack.push(data);
				//System.out.println("Ȯ�ο� ���");
				continue;
			case "pop":
				try {
					 buffer = stack.pop();
				}catch(EmptyStackException e){
					buffer = -1;
					}				
				System.out.println(buffer);
				continue;
			case "size":
				System.out.println(stack.size());
				continue;
			case "empty":
				buffer2 = stack.empty();
				if(buffer2 == false) buffer = 0; else buffer = 1; 
				System.out.println(buffer);
				continue;
			case "top":
				try {
					 buffer = stack.peek();
				}catch(EmptyStackException e){
					buffer = -1;
					}	
				System.out.println(buffer);
				continue;
				
			case "search":
				System.out.println(stack.search(2));
				continue;
			
			}
		}
	}
}
